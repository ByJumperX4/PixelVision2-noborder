LOW RESOLUTION OVERLAY
======================

   These files provide an alternative layout to the ingame overlay, that's more acomodating to resolutions
   lower than 1366 pixels wide. 1366 by 768 should not need to use these yet, but any lower and the default
   version will start causing some very noticeable overlap.
   
   Not to be confused with Steam's own "_lores" layout files, which the ingame overlay automatically swaps
   to when it detects a resolution of 800 by 600 or lower. Those layout files aren't being affected here.



  � Installation
    ------------

	Copy the 2 files in this folder to the previous folder (its parent), more specifically:
	<Steam>\skins\PixelVision\resource\layout\