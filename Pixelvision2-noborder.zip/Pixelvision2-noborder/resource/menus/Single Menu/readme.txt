SINGLE MENU
===========

  � This provides an alternative menu file to use with PixelVision.

  � The result will be a single "Steam" menu with the options from all other menus.

  � To install it, simply overwrite steam.menu in the previous folder with the one in this folder.