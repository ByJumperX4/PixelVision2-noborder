PixelVision²
============

Made possible thanks to Pulseh

Continued by Mr. late, Shazam, somini, Black4Blade

Outstanding issues
-----
The SteamVR button is hidden until a solution is found. Check out the issue [#43](https://github.com/somini/Pixelvision2/issues/43) for discussion.

Fonts
-----
The skin requires a set of fonts installed on your system, of the SegoeWP family.
You can download them [here][fonts].

CRC-32: 1616ac72

   MD4: 1936e15c27a076116d000637a0b5d15e
   
   MD5: adaed62ead549d862dc348bd56cc9d39
   
 SHA-1: f2323868bacd25842617e626b7f26bd94c63dc51

[fonts]: http://www.mediafire.com/file/k4makp2pk726bmb/Fonts.zip
