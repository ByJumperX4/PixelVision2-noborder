Be sure to enable the "Replace Big Picture Mode Icon" tweak located in the settings.ini
